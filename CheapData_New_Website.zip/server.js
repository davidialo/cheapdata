require("dotenv").config();
const express=require("express"), path=require("path"), crypto=require("crypto");
const app=express(); app.use(express.json()); app.use(express.static(path.join(__dirname,"public")));
const PORT=process.env.PORT||3000, BASE=process.env.VTPASS_BASE_URL||"https://sandbox.vtpass.com/api";
function requestId(){return new Date().toISOString().replace(/\D/g,"").slice(0,14)+crypto.randomBytes(4).toString("hex");}
app.post("/api/airtime",async(req,res)=>{
 try{
  const {network,amount,phone}=req.body;
  const services={mtn:"mtn",airtel:"airtel",glo:"glo","9mobile":"etisalat"};
  if(!services[network]||!Number(amount)||!/^[0]\d{10}$/.test(String(phone))) return res.status(400).json({ok:false,message:"Check network, amount and phone number."});
  if(!process.env.VTPASS_API_KEY||!process.env.VTPASS_SECRET_KEY) return res.status(500).json({ok:false,message:"VTpass credentials are not configured."});
  const r=await fetch(BASE+"/pay",{method:"POST",headers:{"Content-Type":"application/json","api-key":process.env.VTPASS_API_KEY,"secret-key":process.env.VTPASS_SECRET_KEY},body:JSON.stringify({request_id:requestId(),serviceID:services[network],amount:Number(amount),phone:String(phone)})});
  const data=await r.json(); res.status(r.ok?200:502).json({ok:r.ok,data});
 }catch(e){res.status(500).json({ok:false,message:"Unable to reach payment service.",error:e.message});}
});
app.listen(PORT,()=>console.log("CheapData running on http://localhost:"+PORT));