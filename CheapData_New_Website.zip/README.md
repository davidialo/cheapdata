# CheapData
A clean airtime VTU starter connected to VTpass Sandbox.

1. Copy `.env.example` to `.env`.
2. Add your Sandbox credentials to `.env`.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Never share or upload `.env` or your secret key.
